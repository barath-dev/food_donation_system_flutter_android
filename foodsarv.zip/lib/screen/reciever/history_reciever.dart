import 'package:flutter/material.dart';


class HistoryReciever extends StatefulWidget {
  const HistoryReciever({super.key});

  @override
  State<HistoryReciever> createState() => _HistoryRecieverState();
}

class _HistoryRecieverState extends State<HistoryReciever> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}