import 'package:flutter/material.dart';

class RequestDonation extends StatefulWidget {
  const RequestDonation({super.key});

  @override
  State<RequestDonation> createState() => _RequestDonationState();
}

class _RequestDonationState extends State<RequestDonation> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}