import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:foodsarv01/models/donation.dart';

class ViewRequests extends StatefulWidget {
  final Donation donation;
  const ViewRequests({super.key, required this.donation});

  @override
  State<ViewRequests> createState() => _ViewRequestsState();
}

class _ViewRequestsState extends State<ViewRequests> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Requests"),
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection("users")
            .where('requests', arrayContains: widget.donation.rid)
            .snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.hasData) {
            if (snapshot.data!.docs.isEmpty) {
              return const Center(
                child: Text("No requests made yet",
                    style: TextStyle(fontSize: 20, color: Colors.black)),
              );
            }
            return ListView.builder(
              itemCount: snapshot.data!.docs.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Card(
                    child: ListTile(
                      onTap: () {},
                      title: Text(snapshot.data!.docs[index]['name']),
                      subtitle: Text(snapshot.data!.docs[index]['mobile'] +
                          "\n" +
                          snapshot.data!.docs[index]['location'] +
                          "\n" +
                          snapshot.data!.docs[index]['status'] +
                          "\n" +
                          snapshot.data!.docs[index]['quantity'].toString() +
                          " " +
                          snapshot.data!.docs[index]['unit'] +
                          "\n" +
                          snapshot.data!.docs[index]['foodName'] +
                          "\n" +
                          snapshot.data!.docs[index]['pickup_time']
                              .toDate()
                              .toString() +
                          "\n" +
                          snapshot.data!.docs[index]['expiry_time']
                              .toDate()
                              .toString()),
                      // leading: CircleAvatar(
                      //   backgroundImage: NetworkImage(),
                      // ),
                    ),
                  ),
                );
              },
            );
          } else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }
}
